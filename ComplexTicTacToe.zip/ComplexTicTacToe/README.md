# Complex Tic Tac Toe
#### Video Demo:  <URL HERE>
#### Description:
A game of tic tac toe built on python using the pygame module. It is not a typical/traditional game of tic tac toe. The map of the game is not 3 by 3 but a lot more complex than that and each player has only 9 moves in total.