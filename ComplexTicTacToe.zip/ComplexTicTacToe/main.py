import pygame
import math


pygame.init()

# WINDOW
width = 700
height = 700
rows = 7
window = pygame.display.set_mode((width, height))
pygame.display.set_caption("Complex Tic Tac Toe")
NULS = 0
playability_array = [[None, NULS, NULS, None, NULS, NULS, None],
                     [NULS, None, NULS, None, NULS, None, NULS],
                     [NULS, NULS, None, None, None, NULS, NULS],
                     [None, None, None, NULS, None, None, None],
                     [NULS, NULS, None, None, None, NULS, NULS],
                     [NULS, None, NULS, None, NULS, None, NULS],
                     [None, NULS, NULS, None, NULS, NULS, None]]
# Colors
white = (255, 255, 255)
black = (0, 0, 0)
gray = (200, 200, 200)

# Images
ICON1 = pygame.transform.scale(pygame.image.load("images/x.png"), (80, 80))
ICON2 = pygame.transform.scale(pygame.image.load("images/y.png"), (80, 80))


font = pygame.font.SysFont('arial', 40)


def makegrid():
    gap = width // rows

    # Starting points
    x = 0
    y = 0

    for i in range(rows):
        x = i * gap

        pygame.draw.line(window, gray, (x, 0), (x, width), 7)
        pygame.draw.line(window, gray, (0, x), (width, x), 7)
    for i in range(len(playability_array)):
        for j in range(len(playability_array[i])):
            if playability_array[i][j] == NULS:

                rect = pygame.Rect(i * 100, j * 100,
                                   100, 100)
                pygame.draw.rect(window, black, rect)

                '''start_x = (i)*100
                end_x = start_x + 100
                start_y = (j)*100
                end_y = start_y + 100
                pygame.draw.rect(window, gray, pygame.Rect(start_x, end_x, start_y, end_y))
'''

def initialize_grid():
    CentreDistance = width // rows // 2
    # Initializing the array
    RecordArray = [[None, NULS, NULS, None, NULS, NULS, None],
                  [NULS, None, NULS, None, NULS, None, NULS],
                  [NULS, NULS, None, None, None, NULS, NULS],
                  [None, None, None, NULS, None, None, None],
                  [NULS, NULS, None, None, None, NULS, NULS],
                  [NULS, None, NULS, None, NULS, None, NULS],
                  [None, NULS, NULS, None, NULS, NULS, None]]

# flag for total count

    for i in range(len(RecordArray)):
        for j in range(len(RecordArray[i])):
            x = CentreDistance * (2 * j + 1)
            y = CentreDistance * (2 * i + 1)

            # Adding centre coordinates
            RecordArray[i][j] = (x, y, "", True)

    return RecordArray


def click(RecordArray):
    global P1_turn, P2_turn, images
    #took some help for the box choice mechanism
    # Mouse position
    m_x, m_y = pygame.mouse.get_pos()

    for i in range(len(RecordArray)):
        for j in range(len(RecordArray[i])):
            x, y, char, can_play = RecordArray[i][j]

            # checking square
            distance = math.sqrt((x - m_x) ** 2 + (y - m_y) ** 2)

            # If it's inside the square
            if playability_array[i][j] != NULS:
                if distance < width // rows // 2 and can_play:
                    if P1_turn:  # If it's p1's turn
                        images.append((x, y, ICON1))
                        P1_turn = False
                        P2_turn = True
                        RecordArray[i][j] = (x, y, 'Player 1', False)

                    elif P2_turn:  # If it's p2's turn
                        images.append((x, y, ICON2))
                        P1_turn = True
                        P2_turn = False
                        RecordArray[i][j] = (x, y, 'Player 2', False)


def has_point(RecordArray):
    # Checking left row
    if (RecordArray[3][0][2] == RecordArray[3][1][2] == RecordArray[3][2][2]) and RecordArray[3][0][2] != "":
        display_message(RecordArray[3][0][2].upper() + " has won!")
        return True
    # Checking right row
    if (RecordArray[3][4][2] == RecordArray[3][5][2] == RecordArray[3][6][2]) and RecordArray[3][4][2] != "":
        display_message(RecordArray[3][4][2].upper() + " has won!")
        return True
    # Checking top row
    if (RecordArray[2][2][2] == RecordArray[2][3][2] == RecordArray[2][4][2]) and RecordArray[2][2][2] != "":
        display_message(RecordArray[2][2][2].upper() + " has won!")
        return True
    # Checking bottom row
    if (RecordArray[4][2][2] == RecordArray[4][3][2] == RecordArray[4][4][2]) and RecordArray[4][2][2] != "":
        display_message(RecordArray[4][2][2].upper() + " has won!")
        return True

    # Checking top column

    if (RecordArray[0][3][2] == RecordArray[1][3][2] == RecordArray[2][3][2]) and RecordArray[0][3][2] != "":
        display_message(RecordArray[0][3][2].upper() + " has won!")
        return True

    # Checking bottom column
    if (RecordArray[4][3][2] == RecordArray[5][3][2] == RecordArray[6][3][2]) and RecordArray[4][3][2] != "":
        display_message(RecordArray[4][3][2].upper() + " has won!")
        return True

    # Checking left column
    if (RecordArray[2][2][2] == RecordArray[3][2][2] == RecordArray[4][2][2]) and RecordArray[2][2][2] != "":
        display_message(RecordArray[2][2][2].upper() + " has won!")
        return True

    # Checking right column
    if (RecordArray[2][4][2] == RecordArray[3][4][2] == RecordArray[4][4][2]) and RecordArray[2][4][2] != "":
        display_message(RecordArray[2][4][2].upper() + " has won!")
        return True

    # Checking TL diagonal
    if (RecordArray[0][0][2] == RecordArray[1][1][2] == RecordArray[2][2][2]) and RecordArray[0][0][2] != "":
        display_message(RecordArray[0][0][2].upper() + " has won!")
        return True


    # Checking BL diagonal
    if (RecordArray[6][0][2] == RecordArray[5][1][2] == RecordArray[4][2][2]) and RecordArray[6][0][2] != "":
        display_message(RecordArray[6][0][2].upper() + " has won!")
        return True

    # Checking TR diagonal
    if (RecordArray[0][6][2] == RecordArray[1][5][2] == RecordArray[2][4][2]) and RecordArray[0][6][2] != "":
        display_message(RecordArray[0][6][2].upper() + " has won!")
        return True

    # Checking BR diagonal
    if (RecordArray[4][4][2] == RecordArray[5][5][2] == RecordArray[6][6][2]) and RecordArray[4][4][2] != "":
        display_message(RecordArray[4][4][2].upper() + " has won!")
        return True

    return False


def has_drawn(RecordArray):
    for i in range(len(RecordArray)):
        for j in range(len(RecordArray[i])):
            if RecordArray[i][j][2] == "":
                return False

    display_message("It's a draw!")
    return True


def display_message(content):
    pygame.time.delay(400)
    window.fill(white)
    end_text = font.render(content, 1, black)
    window.blit(end_text, ((width - end_text.get_width()) // 2, (width - end_text.get_height()) // 2))
    pygame.display.update()
    pygame.time.delay(2000)


def render():
    window.fill(white)
    makegrid()

    # Drawing p1's and p2's icons
    for image in images:
        x, y, IMAGE = image
        window.blit(IMAGE, (x - IMAGE.get_width() // 2, y - IMAGE.get_height() // 2))

    pygame.display.update()


def main():
    global P1_turn, P2_turn, images, draw

    images = []
    draw = False

    run = True



    P1_turn = True
    P2_turn = False

    P1_TRIES = 9
    P2_TRIES = 9
    RecordArray = initialize_grid()

    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if P2_turn:
                    if P2_TRIES > 0:
                        click(RecordArray)
                        P2_TRIES -= 1
                    else:
                        display_message("Out of moves")
                        display_message("STARTING NEW GAME...")
                        run = False

                else:
                    if P1_TRIES > 0:
                        click(RecordArray)
                        P1_TRIES -= 1
                    else:
                        display_message("Out of moves")
                        display_message("STARTING NEW GAME...")
                        run = False

        render()

        if has_point(RecordArray) or has_drawn(RecordArray):
            display_message("STARTING NEW GAME...")

            run = False

y = True

while y:
    main()
